// Code goes here

var SimpleListModel = function(items) {
    this.items = ko.observableArray(items);
    this.itemToAdd = ko.observable("");
    this.addItem = function() {
        if (this.itemToAdd() != "") {
        	// Adds the item. Writing to the "items" observableArray causes any associated UI to update.
            this.items.push(this.itemToAdd()); 
            // Clears the text box, because it's bound to the "itemToAdd" observable
            this.itemToAdd(""); 
        }
    }.bind(this);  // Ensure that "this" is always this view model
};
 
ko.applyBindings(new SimpleListModel(["Alpha", "Beta", "Gamma"]));

