﻿
(function () {

    function ShoppingCart(productId, productName, productCode, Price, Qty) {

        var self = this;
        self.productId = productId;
        self.productName = productName;
        self.productCode = productCode;
        self.Price = Price;
        self.Qty = Qty;
    };

    self.ShoppingCart = ShoppingCart;
})();