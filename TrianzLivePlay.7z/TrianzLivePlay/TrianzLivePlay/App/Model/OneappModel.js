﻿(function (oneapp) {
    //model
    function Student(id, name, grade) {
        var self = this;
        self.id = id;
        self.name = name;
        self.grade = grade;

    }


    oneapp.Student = Student;

}(window.oneapp));