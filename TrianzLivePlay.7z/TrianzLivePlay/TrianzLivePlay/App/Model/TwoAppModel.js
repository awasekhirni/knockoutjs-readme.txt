﻿
//model with iife
  (function (twoapp) {

    function Employee(id, fName, lName, dob, gender, paygrade, designation, department,salary, taxrate) {

     



        var self = this;
        //two binding 
        //pub-sub //observer pattern 

        self.id = ko.observable(id);
        self.fName = ko.observable(fName);
        self.lName = ko.observable(lName);
        self.dob = ko.observable(dob);
        self.gender =ko.observable( gender);
        self.paygrade = ko.observable(paygrade);
        self.designation = ko.observable(designation);
        self.department = ko.observable(department);
        self.salary = ko.observable(salary);
        self.taxrate = ko.observable(taxrate);

       
    }

    twoapp.Employee = Employee;

}(window.twoapp));