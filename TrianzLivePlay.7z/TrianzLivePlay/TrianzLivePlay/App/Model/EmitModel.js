﻿

(function () {

    function SalesData(month, averagemonthlysales, location) {
        var self = this;
        self.month = month;

        self.averagemonthlysales = averagemonthlysales;
        self.location = location;

    }

    self.SalesData = SalesData;

})();