﻿
(function () {

    function UserInfo(fName, lName, dob) {
        var self = this;
        this.fName = ko.observable(fName);
        this.lName = ko.observable(lName);
        this.dob = ko.observable(dob);
    }

    self.UserInfo = UserInfo;

})();
