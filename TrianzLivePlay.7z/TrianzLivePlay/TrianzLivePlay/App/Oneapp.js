﻿
window.oneapp = {};