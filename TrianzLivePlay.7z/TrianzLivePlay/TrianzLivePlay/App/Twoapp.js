﻿//namespace binding
window.twoapp = {};