﻿//iffe with standard notation
(function () {

    function viewModel() {
        var self = this;

        self.todotasks = ko.observableArray([
           { task: 'Introduction to Javascript Frameworks' },
           { task: 'JQuery Before KO' },
           { task: 'Choosing the right JavaScript Frameworks' },
           { task: 'MVC,MVP and MVVM frameworks' },
           { task: 'KO Pearls' },
           { task: 'Observables' }

        ]);

        self.addTask = function () {
            self.todotasks.push({ task: $('#newtask').val() });
        }

        //behaviour -> remove task
        self.removetask = function () {
            self.todotasks.remove(this);
        };

    }

    // binds to the body
    $(document).ready(function () {
        ko.applyBindings(new viewModel());
    });
  


})();