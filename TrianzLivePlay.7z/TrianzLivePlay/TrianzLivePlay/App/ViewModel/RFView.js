﻿
(function () {

    function viewModel() {
        var self = this;
        self.response = ko.observable();

        self.sak = new UserInfo('Awase', 'Syed', '03/03/1976');

        self.onSubmit = function () {
            var data = JSON.stringify(
                {
                    first: self.sak.fName(), last: self.sak.lName()
                });
            $.post("/echo/json", data, function (response) {
                // on success callback
                self.response(response);
            })
        }

    };

    $(document).ready(function () {
        var jsonData = ko.toJSON(viewModel);
        var plainJS = ko.toJS(viewModel);
        ko.applyBindings(new viewModel())


        
    });


})();

