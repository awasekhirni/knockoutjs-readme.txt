﻿
(function (thirdapp) {


    function GithubUserVM() {

        var self = this;
        self.records = ko.observableArray([]);

        $.getJSON("https://api.github.com/users/shiva", function (data) {
            console.log("data retrieved from github:" + data);
            console.log(data.login);
            console.log(data.name);
            self.records(data);
        })
    }

    ko.applyBindings(new GithubUserVM());

}(window.thirdapp));