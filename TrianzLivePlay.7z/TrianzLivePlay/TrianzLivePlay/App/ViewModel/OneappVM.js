﻿
//view model 
//iife
//douglas crockford notation
(function (oneapp) {
    
    
    function ViewModel() {
        //instantiate the object defined in the model
        var self = this;
       
       self.s = new oneapp.Student(112231, 'James Bond', 10);
     
    };

    // binding the model to the view model and to the view
    ko.applyBindings(new ViewModel());



}(window.oneapp));

