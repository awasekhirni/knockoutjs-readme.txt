﻿

(function (twoapp) {


    function viewModel() {
        var self = this;
        
        var sak = new twoapp.Employee(324423, 'awase', 'syed', '3/3/1976', 'male', 'A3', 'STA', 'R &D',6000000, 30);

        self.emp = sak;

       

        //computed value -> ko.computed 
        self.emp.netpay = ko.computed(function (salary,taxrate) {
            console.log(sak.salary());
            var val = parseInt(sak.salary()) * parseInt(sak.taxrate()) / 100;
            console.log(val);
            var np = parseInt(sak.salary()) - parseInt(val);
            console.log(np);
            return np
        });


    }

    ko.applyBindings(new viewModel());



}(window.twoapp));