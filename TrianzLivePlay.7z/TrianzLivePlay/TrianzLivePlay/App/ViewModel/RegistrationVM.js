﻿
(function () {
    var that = this;

    function RegisterVM() {
        var self = this;

        self.name = "Syed Awase Khirni";
     

    };





    ko.components.register('form-register', {
        viewModel:RegisterVM,
        template: '<input type="password" class="form-control" name="confirm" id="confirm" placeholder="Confirm your Password" />'+' <span data-bind="text:name"></span>'
    });


    $(document).ready(function () {

        ko.applyBindings(new RegisterVM())
    });

})();