﻿
(function (materializeapp) {

    var liveplayoneViewModel = {
        name: ko.observable(" Syed Awase Khirni"),
        changeName: function () {
            this.name("Syed Ameese Sadath");
        },
        nameVisible: ko.observable(true)

    };

    //apply the bindings to the view 
    ko.applyBindings(liveplayoneViewModel);




}(window.materializeapp));