﻿
(function (movieapp) {


    function MovieVM() {

        var self = this;
        self.movies = ko.observableArray([]);

        $.getJSON("http://www.omdbapi.com/?t=frozen&y=2015&plot=short&r=json", function (data) {
            console.log(data);
            self.movies(data);

        });


    };

    ko.applyBindings(new MovieVM());



}(window.movieapp));