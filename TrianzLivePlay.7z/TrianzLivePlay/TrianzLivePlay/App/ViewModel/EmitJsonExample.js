﻿
(function () {

    function viewModel() {
        var self = this;

        self.SalesData = ko.observableArray([]);

        var zip = "560000";
        for (var i = 0; i < 12; i++) {
            self.SalesData.push(new SalesData(
                i,
                i * Math.random(12) * 10,
                 parseInt(zip)+i

                ));
        }




    };

    $(document).ready(function () {

        ko.applyBindings(new viewModel())
    });


})();