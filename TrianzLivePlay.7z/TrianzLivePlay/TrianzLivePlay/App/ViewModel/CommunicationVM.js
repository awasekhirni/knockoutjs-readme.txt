﻿
(function () {

    //accountviewModel
    var accountViewModel = function () {
       
        var _id = 'UK1231241';
        var _accountName = 'sak008';

        var _balance = 100000;
        this.getaccountName = function () {
            return _accountName;
        };
        this.getId = function () {
            return _id;
        };
        this.getbalance = function () {
            return _balance;
        }
    };


    //cartviewModel 
    var cartViewModel = function () {
       
      var _productId = 'MS12321312',
                _productName = 'Red Tape',
                _price = 2900;
        this.getproductId = function () {
            return _productId;
        };
        this.getproductName = function () {
            return _productName;
        };
        this.getprice = function () {
            return _price;
        };
    };


    //masterview model
    var CheckoutViewModel = function () {
        this.ac = new accountViewModel();
        this.cm = new cartViewModel();
        this.postpurchasebalance =
            function () {
                
             return (  this.ac.getbalance() - this.cm.getprice());
               
                
            };
        console.log(this.postpurchasebalance());
    };

    $(document).ready(function () {
        ko.applyBindings(new CheckoutViewModel());
    });




})();