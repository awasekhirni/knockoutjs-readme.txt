﻿
(function () {

    function ShoppingVM(){

        var self = this;

        self.productCode = [
            { name: 'Mens Wear', code: 'FM4232' },
            { name: 'Womens Wear', code: 'FW232' },
            { name: 'Electrical Appliances', code: 'EA32' },
            { name: 'Mobile', code: 'M8232' },
            { name: 'Sport', code: 'S98232' },
            { name: 'Kids wear', code: 'k132' }
           
        ]

        self.ShoppingCart = new ShoppingCart(0, '', self.productCode, 0, 0);
          
        
    };

    $(document).ready(function () {
        ko.applyBindings(new ShoppingVM());

    });




})();