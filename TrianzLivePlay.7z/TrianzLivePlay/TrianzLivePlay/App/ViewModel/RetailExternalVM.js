﻿

(function () {


    function RetailEVM() {
        var self = this;
        self.records = ko.observableArray([]);

        console.log(" ----inside --evm");
        $.getJSON('http://api.github.com/users/shiva', function (data) {
            console.log(data);
            self.records(data.product);
        });

        $(document).ready(function () {
            var viewmodel = new RetailEVM();
            var templateid = 'template/retail-stamper.html';
            var targetId = 'retail';
           
            //external template calling 
           
            $.ajax(templateid, { async: false }).success(function (stream) {
                console.log(stream);
                $('#' + targetId).html(stream);
                ko.applyBindings(viewmodel, document.getElementById(targetId));
            });


            ko.applyBindings(viewmodel);
        });



    };


})();