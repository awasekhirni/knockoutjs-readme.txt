﻿
(function () {

    function RetailVM() {
        var self = this;
        self.records = ko.observableArray([]);

        $.getJSON('ebay.json', function (data) {
            console.log(data);
            self.records(data.product);
        });



    };

    $(document).ready(function () {
        ko.applyBindings(new RetailVM());
    });



})();